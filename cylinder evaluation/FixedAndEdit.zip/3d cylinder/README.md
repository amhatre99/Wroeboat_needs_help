# 3D Cylinder Estimation

No readme existed, so I'm creating one - Steph

## Installation

1. Install [R](https://cran.r-project.org/)
2. Install [RStudio](https://www.rstudio.com/products/rstudio/download/#download)
3. (Maybe not necessary) Install [RTools](https://cran.r-project.org/)
4. Run install_required.R from RStudio

I already had Visual Studio 2013 installed on my computer, but I do not think it is necessary to have this to compile as RTools appear to install MinGW things.

## Running

Run Tree1.R from RStudio
