# probably already on your system:
install.packages('rgl')

# possibly missing
install.packages('geomorph')
install.packages('FNN')
install.packages('Rcpp')
install.packages('RcppArmadillo')